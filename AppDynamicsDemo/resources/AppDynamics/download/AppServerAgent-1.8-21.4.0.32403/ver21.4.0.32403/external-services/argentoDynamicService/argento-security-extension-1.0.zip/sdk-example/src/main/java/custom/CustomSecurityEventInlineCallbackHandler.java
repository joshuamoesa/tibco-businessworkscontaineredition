package custom;


import com.cisco.argento.core.SecurityEvent;
import com.cisco.argento.events.SocketConnectionEvent;
import com.cisco.argento.events.reports.ReportEventBuilder;
import com.cisco.argento.sdk.SecurityEventInlineCallback;
import com.cisco.mtagent.tenant.MTAgentTenantAPI;
import com.cisco.mtagent.tenant.MTAgentTenantAPI.TenantDiagnosticsServerInterface;
import com.sun.net.httpserver.HttpExchange;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.config.*;
import org.apache.http.client.methods.*;
import org.apache.http.concurrent.*;
import org.apache.http.entity.*;
import org.apache.http.impl.client.*;
import org.apache.http.impl.nio.client.*;

import java.net.Socket;
import java.net.URL;
import java.security.Permission;
import java.util.Map;
import java.util.concurrent.Future;


public class CustomSecurityEventInlineCallbackHandler extends SecurityEventInlineCallback {

    /*
     * Special Events - non realtime
     *
        SecurityEvent.CONFIGURATION_DETAILS_EVENT
        SecurityEvent.COMPONENT_DETAILS_EVENT
        SecurityEvent.CONNECTION_DETAILS_EVENT

     */
    private SecurityEvent currentConfigurationEvent;
    private SecurityEvent currentComponentsEvent;
    private SecurityEvent currentSocketConnectionEvent;


    @Override
    public void init(MTAgentTenantAPI mtAgentTenantAPI, String homeDir, ReportEventBuilder reportEventBuilder) {
        super.init(mtAgentTenantAPI, homeDir, reportEventBuilder);
        mtAgentTenantAPI.createHandlerService("/CustomCallback", new WebServerInterface());
        Thread t = new Thread() {
            public void run() {
                try {
                    Thread.sleep(30000);
                } catch (Exception e) {
                }
                reportEventBuilder.sendComponentDetailsEvent(false, "SDK");
                reportEventBuilder.sendConfigurationDetailsEvent(false, "SDK");
            }
        };
        t.setDaemon(true);
        t.start();
    }

    //
    // Whatever is done is this Callback should NOT create any operations with new Threads and block waiting for them - as they may need permissions
    // and those permissions will not be granted because this thread is blocking and holding the lock they need via synchronize block
    //
    // If you do create another thread you must:
    //
    //   eventUtils.disableEventsForThread(Thread t);
    //   eventUtils.enableEventsForThread(Thread t);
    //

    @Override
    public boolean securityEventComplete(String id, SecurityEvent se) {
        mtAgentTenantAPI.log("Event Complete Callback is receiving event with id " + id + " event is " + se.toDisplayString());
        return true;
    }


    @Override
    public boolean permissionEvent(Permission permission, String stackTrace, String librarySource, Map<String, String> securityEventInfoMap, SecurityEvent se) {
        mtAgentTenantAPI.log("Permission Event Callback is receiving event: " + permission + " , Thread is " + Thread.currentThread().getName() + " , storedInfo: " + securityEventInfoMap + ", is Transaction Event: " + se.isTransactionEvent());
//        sendHttpSync("http://www.appdynamics.com");
        if (false) {
            se.setBlocked_reason("Unauthorized Permission Request");
            throw new ArgentoSecurityException("Unauthorized Permission Request...");
        }
        return true;
    }

    @Override
    public boolean exceptionEvent(Object inst, String msg, String stackTrace, Throwable cause, SecurityEvent se) {
        mtAgentTenantAPI.log("Exception Event Callback is receiving event, event: " + inst + " , Thread is " + Thread.currentThread().getName() + " , is Transaction Event: " + se.isTransactionEvent());
        return true;
    }

    @Override
    public boolean genericEvent(String eventName, String msg, String stackTrace, SecurityEvent se) {
        mtAgentTenantAPI.log("Generic Event Callback is receiving event, event: " + msg + " , Thread is " + Thread.currentThread().getName() + " , is Transaction Event: " + se.isTransactionEvent());
        if (false) {
            se.setBlocked_reason("Unauthorized Operation");
            throw new ArgentoSecurityException("Unauthorized Operation...");
        }
        return true;
    }

    @Override
    public boolean socketConnectionEvent(Socket socket, String stackTrace, boolean isServer, boolean isNio, URL url, SecurityEvent se) {
        mtAgentTenantAPI.log("Socket Connection Event Callback is receiving event: " + socket + " , Thread is " + Thread.currentThread().getName() + " , is Transaction Event: " + se.isTransactionEvent());
        if (false) {
            se.setBlocked_reason("Unauthorized Socket");
            throw new ArgentoSecurityException("Unauthorized connection between Sockets...");
        }
        return true;
    }

    private void reviewSocketConnections() {
        Map<Socket, SocketConnectionEvent> socketConnectionsHash = SocketConnectionEvent.getSocketConnectionsMap();
        for (Socket sc : socketConnectionsHash.keySet()) {
            SocketConnectionEvent connection = socketConnectionsHash.get(sc);
        }
    }

    protected void sendHttpSync(String target) {
        try {
            HttpClient httpClient = HttpClientBuilder.create().build();
            HttpGet request = new HttpGet(target);
            HttpResponse response = httpClient.execute(request);
            mtAgentTenantAPI.log("Completed..." + response);
        } catch (Exception e) {
            mtAgentTenantAPI.logError("Failure in completion: " + e);
        }
    }


    // IF you want to do a network operation - which is a bad idea due to latency - it must be 100% Synchronous for now

    protected void sendHttpAsync(boolean isAsync, String target) {
        CloseableHttpAsyncClient httpClient = HttpAsyncClients.createDefault();
        httpClient.start();
        HttpGet httpGet = new HttpGet(target);
        if (isAsync) {
            httpClient.execute(httpGet, new FutureCallback<HttpResponse>() {
                public void completed(final HttpResponse response) {
                    mtAgentTenantAPI.log("Completed..." + response);
                    try {
                        httpClient.close();
                    } catch (Exception e) {
                    }
                }

                public void failed(final Exception ex) {
                    mtAgentTenantAPI.logError("Failed.." + ex);
                    try {
                        httpClient.close();
                    } catch (Exception e) {
                    }
                }

                public void cancelled() {
                    mtAgentTenantAPI.log("Cancelled...");
                    try {
                        httpClient.close();
                    } catch (Exception e) {
                    }
                }

            });
        } else {
            Future<HttpResponse> response = httpClient.execute(httpGet, null);
            try {
                httpClient.close();
                mtAgentTenantAPI.log("Completed..." + response.get());
            } catch (Exception e) {
                mtAgentTenantAPI.log("Failure in completion: " + e);
            }
        }
    }

    // Don't use this - it creates multiple threads and blocks waiting for them and they get blocked by this calling thread who is synchonizing - so it will hang

    public static class WebServerInterface implements TenantDiagnosticsServerInterface {
        public String inboundMessage(HttpExchange he, java.util.concurrent.atomic.AtomicInteger statusCode, Map<String, String> params) {
            try {
                statusCode.set(200);
                java.net.InetSocketAddress address = he.getLocalAddress();
                if (params.get("test") != null) {
                    return "Its a test";
                } else {
                    return "Command not understood";
                }

            } catch (Throwable e) {
                if (e.getCause() == null) return e.toString();
                else return "Error: " + e.getCause().toString();
            }
        }
    }


}